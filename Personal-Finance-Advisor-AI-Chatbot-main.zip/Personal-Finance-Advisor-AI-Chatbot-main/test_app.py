import os, tempfile
import pytest
from app import app, db

@pytest.fixture()
def client():
    fd, path = tempfile.mkstemp(suffix='.db'); os.close(fd)
    app.config.update(TESTING=True, SQLALCHEMY_DATABASE_URI='sqlite:///'+path, SECRET_KEY='test')
    with app.app_context(): db.drop_all(); db.create_all()
    with app.test_client() as c: yield c
    try: os.remove(path)
    except OSError: pass

def test_register_login_and_dashboard(client):
    r=client.post('/register',data={'name':'Test User','email':'test@example.com','password':'secret123'},follow_redirects=True)
    assert r.status_code==200
    assert b'MONTHLY INCOME' in r.data

def test_income_updates_dashboard(client):
    client.post('/register',data={'name':'Test','email':'a@b.com','password':'secret123'})
    client.post('/api/income',json={'source':'Allowance','amount':10000})
    data=client.get('/api/dashboard').get_json()
    assert data['income']==10000
