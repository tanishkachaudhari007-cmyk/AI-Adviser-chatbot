# Personal Finance Advisor — Professional Starter

A Flask + SQLAlchemy personal finance management application upgraded around the project requirements you shared.

## Included
- User registration/login with hashed passwords and session-based access.
- User-isolated income, expense, budget and savings-goal records.
- Current-month dashboard with income, expenses, balance and savings rate.
- Income and expense history with delete actions.
- Category budgets with progress bars.
- Savings goals with progress tracking.
- AI Advisor endpoint with optional Gemini integration and a local rules-based fallback.
- Responsive professional dashboard UI.
- SQLite by default; PostgreSQL can be supplied through `DATABASE_URL`.
- Render deployment files (`render.yaml`, `Procfile`) and production WSGI server dependency.
- Basic pytest coverage for registration/login and income dashboard calculation.

## 1. Extract
Extract the ZIP. Open the extracted `PersonalFinanceAdvisor_Professional` folder in VS Code.

## 2. Create a fresh virtual environment (recommended)
PowerShell:
```powershell
cd .\PersonalFinanceAdvisor_Professional
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Configure environment
Copy `.env.example` to `.env` and set a real `SECRET_KEY`.
If you want Gemini responses, add your `GEMINI_API_KEY`.

## 4. Run
```powershell
python app.py
```
Open `http://127.0.0.1:5000`.

## 5. Test
```powershell
pytest
```

## 6. Render
Push the project folder to GitHub. On Render, create a Web Service from the repository. The included `render.yaml` uses:
- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app`

Set `SECRET_KEY`, `GEMINI_API_KEY` (optional), and a persistent PostgreSQL `DATABASE_URL` in Render for production data persistence. SQLite is suitable for local development/demo use.

## Important next upgrades
1. Add database migrations with Flask-Migrate before changing production schemas.
2. Add CSRF protection for production forms/APIs.
3. Add rate limiting and stronger password rules.
4. Add monthly report export (PDF/CSV).
5. Add recurring transactions and notification/reminder support.
6. Add richer analytics and a dedicated reports page.
7. Add automated deployment tests and error monitoring.

This project is intended for educational budgeting and financial-management use, not regulated financial advice.
