# Project roadmap mapped to the requirement document

| Requirement area | Starter status |
|---|---|
| Environment & AI configuration | Included |
| User registration/login/session/profile foundation | Included |
| Income & expense tracking | Included |
| Budget planning & spending analysis | Included |
| AI recommendations | Included with Gemini + fallback |
| Dashboard & analytics | Included |
| Database management | Included |
| Frontend/backend API integration | Included |
| Public deployment | Render config included |
| Testing & validation | Basic pytest included |
| Monthly reports | Next upgrade |
| Advanced security hardening | Next upgrade |
| Emergency-fund module | Next upgrade |
| PostgreSQL production persistence | Configure `DATABASE_URL` |
