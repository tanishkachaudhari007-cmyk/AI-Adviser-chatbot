from datetime import date, datetime
from functools import wraps
import os

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'change-this-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///' + os.path.join(BASE_DIR, 'finance.db'))
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

CATEGORIES = ['Food', 'Rent', 'Transport', 'Education', 'Healthcare', 'Entertainment', 'Shopping', 'Bills', 'Other']

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Income(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    source = db.Column(db.String(120), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    entry_date = db.Column(db.Date, nullable=False, default=date.today)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    title = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    entry_date = db.Column(db.Date, nullable=False, default=date.today)

class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    category = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    __table_args__ = (db.UniqueConstraint('user_id', 'category', name='uq_user_budget_category'),)

class SavingGoal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    target = db.Column(db.Float, nullable=False)
    saved = db.Column(db.Float, nullable=False, default=0)

with app.app_context():
    db.create_all()


def current_user():
    uid = session.get('user_id')
    return db.session.get(User, uid) if uid else None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            if request.path.startswith('/api/'):
                return jsonify({'error': 'Login required.'}), 401
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper


def parse_date(value):
    return datetime.strptime(value, '%Y-%m-%d').date() if value else date.today()


def month_totals(user_id, year=None, month=None):
    today = date.today()
    year = year or today.year
    month = month or today.month
    incomes = Income.query.filter_by(user_id=user_id).filter(db.extract('year', Income.entry_date) == year, db.extract('month', Income.entry_date) == month).all()
    expenses = Expense.query.filter_by(user_id=user_id).filter(db.extract('year', Expense.entry_date) == year, db.extract('month', Expense.entry_date) == month).all()
    by_category = {c: 0 for c in CATEGORIES}
    for item in expenses:
        by_category[item.category] = by_category.get(item.category, 0) + item.amount
    income = sum(x.amount for x in incomes)
    expense = sum(x.amount for x in expenses)
    return income, expense, by_category


def build_advice(user_id):
    income, expenses, by_category = month_totals(user_id)
    balance = income - expenses
    savings_rate = (balance / income * 100) if income else 0
    active = [(k, v) for k, v in by_category.items() if v > 0]
    top = max(active, key=lambda x: x[1]) if active else ('None', 0)
    tips = []
    if not income:
        tips.append('Add your monthly income to generate a realistic budget plan.')
    if top[1]:
        tips.append(f'{top[0]} is your highest spending category at ₹{top[1]:,.0f}. Review whether some spending can be reduced.')
    if income and expenses > income:
        tips.append('Recorded expenses are above income. Review discretionary spending and set category limits.')
    elif income and savings_rate < 20:
        tips.append('Your current recorded savings rate is below 20%. Consider setting a small weekly spending limit.')
    elif income:
        tips.append('Your recorded expenses are below income. Consider moving a fixed amount toward a savings goal.')
    budgets = {b.category: b.amount for b in Budget.query.filter_by(user_id=user_id).all()}
    for category, spent in active:
        if budgets.get(category) and spent > budgets[category]:
            tips.append(f'{category} is over its budget by ₹{spent - budgets[category]:,.0f}.')
    return tips[:5]


def gemini_advice(user_id, question):
    key = os.getenv('GEMINI_API_KEY')
    if not key:
        return None
    try:
        from google import genai
        income, expenses, by_category = month_totals(user_id)
        budgets = {b.category: b.amount for b in Budget.query.filter_by(user_id=user_id).all()}
        goals = [{'name': g.name, 'target': g.target, 'saved': g.saved} for g in SavingGoal.query.filter_by(user_id=user_id).all()]
        context = {'monthly_income': round(income, 2), 'monthly_expenses': round(expenses, 2), 'balance': round(income-expenses, 2), 'expense_by_category': {k: round(v,2) for k,v in by_category.items() if v}, 'budgets': budgets, 'goals': goals}
        prompt = f'''You are a personal-finance education assistant inside a student project. Use only the supplied data. Do not claim to be a licensed financial advisor. Do not provide personalized investment, tax, securities, or loan recommendations. Give practical budgeting and saving guidance. User data: {context}. Question: {question}. Answer simply with 2-4 actionable suggestions.'''
        client = genai.Client(api_key=key)
        model = os.getenv('GEMINI_MODEL', 'gemini-2.5-flash')
        response = client.models.generate_content(model=model, contents=prompt)
        return response.text.strip() if response.text else None
    except Exception as exc:
        app.logger.warning('Gemini unavailable: %s', exc)
        return None

@app.context_processor
def inject_globals():
    return {'user': current_user(), 'categories': CATEGORIES}

@app.route('/')
def home():
    return redirect(url_for('dashboard') if current_user() else url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear(); session['user_id'] = user.id
            return redirect(url_for('dashboard'))
        return render_template('login.html', error='Invalid email or password.')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        if not name or not email or len(password) < 6:
            return render_template('register.html', error='Enter a name, valid email, and password of at least 6 characters.')
        if User.query.filter_by(email=email).first():
            return render_template('register.html', error='An account with this email already exists.')
        user = User(name=name, email=email, password_hash=generate_password_hash(password))
        db.session.add(user); db.session.commit()
        session['user_id'] = user.id
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.post('/logout')
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('index.html')

@app.get('/api/dashboard')
@login_required
def api_dashboard():
    uid = current_user().id
    income, expenses, by_category = month_totals(uid)
    budgets = {b.category: b.amount for b in Budget.query.filter_by(user_id=uid).all()}
    goals = SavingGoal.query.filter_by(user_id=uid).all()
    return jsonify({'income': round(income,2), 'expenses': round(expenses,2), 'balance': round(income-expenses,2), 'savings_rate': round((income-expenses)/income*100,1) if income else 0, 'categories': {k: round(v,2) for k,v in by_category.items()}, 'budgets': budgets, 'goals': [{'id':g.id,'name':g.name,'target':g.target,'saved':g.saved} for g in goals], 'advice': build_advice(uid)})

@app.get('/api/income')
@login_required
def api_income():
    rows = Income.query.filter_by(user_id=current_user().id).order_by(Income.entry_date.desc(), Income.id.desc()).all()
    return jsonify([{'id':x.id,'source':x.source,'amount':x.amount,'date':x.entry_date.isoformat()} for x in rows])

@app.post('/api/income')
@login_required
def add_income():
    data=request.get_json() or {}; source=str(data.get('source','')).strip()
    try: amount=float(data.get('amount',0))
    except: amount=0
    if not source or amount<=0: return jsonify({'error':'Enter a valid source and positive amount.'}),400
    db.session.add(Income(user_id=current_user().id, source=source, amount=amount, entry_date=parse_date(data.get('date')))); db.session.commit()
    return jsonify({'message':'Income added.'})

@app.delete('/api/income/<int:item_id>')
@login_required
def delete_income(item_id):
    item=Income.query.filter_by(id=item_id,user_id=current_user().id).first_or_404(); db.session.delete(item); db.session.commit(); return jsonify({'message':'Income deleted.'})

@app.get('/api/expense')
@login_required
def api_expense():
    rows=Expense.query.filter_by(user_id=current_user().id).order_by(Expense.entry_date.desc(), Expense.id.desc()).all()
    return jsonify([{'id':x.id,'title':x.title,'category':x.category,'amount':x.amount,'date':x.entry_date.isoformat()} for x in rows])

@app.post('/api/expense')
@login_required
def add_expense():
    data=request.get_json() or {}; title=str(data.get('title','')).strip(); category=str(data.get('category','')).strip()
    try: amount=float(data.get('amount',0))
    except: amount=0
    if not title or category not in CATEGORIES or amount<=0: return jsonify({'error':'Enter valid expense details.'}),400
    db.session.add(Expense(user_id=current_user().id,title=title,category=category,amount=amount,entry_date=parse_date(data.get('date')))); db.session.commit(); return jsonify({'message':'Expense added.'})

@app.delete('/api/expense/<int:item_id>')
@login_required
def delete_expense(item_id):
    item=Expense.query.filter_by(id=item_id,user_id=current_user().id).first_or_404(); db.session.delete(item); db.session.commit(); return jsonify({'message':'Expense deleted.'})

@app.post('/api/budget')
@login_required
def save_budget():
    data=request.get_json() or {}; category=str(data.get('category','')).strip()
    try: amount=float(data.get('amount',0))
    except: amount=0
    if category not in CATEGORIES or amount<=0: return jsonify({'error':'Enter a valid budget.'}),400
    item=Budget.query.filter_by(user_id=current_user().id,category=category).first()
    if item: item.amount=amount
    else: db.session.add(Budget(user_id=current_user().id,category=category,amount=amount))
    db.session.commit(); return jsonify({'message':'Budget saved.'})

@app.post('/api/goal')
@login_required
def add_goal():
    data=request.get_json() or {}; name=str(data.get('name','')).strip()
    try: target=float(data.get('target',0))
    except: target=0
    if not name or target<=0: return jsonify({'error':'Enter a valid saving goal.'}),400
    db.session.add(SavingGoal(user_id=current_user().id,name=name,target=target,saved=0)); db.session.commit(); return jsonify({'message':'Saving goal added.'})

@app.put('/api/goal/<int:goal_id>')
@login_required
def update_goal(goal_id):
    goal=SavingGoal.query.filter_by(id=goal_id,user_id=current_user().id).first_or_404(); data=request.get_json() or {}
    try: saved=float(data.get('saved',0))
    except: return jsonify({'error':'Enter a valid savings amount.'}),400
    if saved<0 or saved>goal.target: return jsonify({'error':'Saved amount must be between 0 and the target.'}),400
    goal.saved=saved; db.session.commit(); return jsonify({'message':'Saving goal updated.'})

@app.post('/api/advisor')
@login_required
def advisor():
    question=str((request.get_json() or {}).get('question','')).strip() or 'How can I improve my budget this month?'
    answer=gemini_advice(current_user().id,question)
    ai_enabled=bool(os.getenv('GEMINI_API_KEY'))
    if not answer: answer='\n'.join('• '+x for x in build_advice(current_user().id))
    return jsonify({'answer':answer,'ai_enabled':ai_enabled})

@app.get('/api/health')
def health(): return jsonify({'status':'ok'})

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=int(os.getenv('PORT',5000)))
